import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const PORT = process.env.PORT || 8787;

app.get("/api/health", (_, res) => {
  res.json({ ok: true, service: "bestdot.AI CreatorOS API" });
});

app.post("/api/generate", async (req, res) => {
  try {
    const { prompt, mode = "Content" } = req.body;
    if (!prompt?.trim()) return res.status(400).json({ error: "Prompt is required." });

    if (!process.env.AI_API_KEY || !process.env.AI_BASE_URL || !process.env.AI_MODEL) {
      return res.status(503).json({
        error: "AI backend is not configured.",
        setup: "Set AI_API_KEY, AI_BASE_URL and AI_MODEL in .env"
      });
    }

    const system = `You are bestdot.AI CreatorOS, an expert AI business/content copilot.
Return practical, concise, execution-ready results in Indonesian.
Mode: ${mode}.
Structure your answer with clear headings, numbered steps, hooks, scripts, CTAs, and next actions when relevant.
Do not invent product facts that were not provided.`;

    const response = await fetch(`${process.env.AI_BASE_URL.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.AI_API_KEY}`
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL,
        temperature: 0.7,
        messages: [
          { role: "system", content: system },
          { role: "user", content: prompt }
        ]
      })
    });

    if (!response.ok) {
      const detail = await response.text();
      return res.status(502).json({ error: "AI provider error", detail });
    }

    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content || "No content returned.";
    res.json({ ok: true, content, model: process.env.AI_MODEL });
  } catch (err) {
    res.status(500).json({ error: "Generation failed", detail: err.message });
  }
});

app.listen(PORT, () => console.log(`bestdot.AI API running on http://localhost:${PORT}`));
