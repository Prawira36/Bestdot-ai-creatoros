# bestdot.AI CreatorOS v2 — AI Engine

Versi ini menambahkan backend API nyata untuk menghubungkan UI CreatorOS ke model AI yang kompatibel dengan endpoint `/chat/completions`.

## Setup

1. Install Node.js 18+.
2. Buka terminal di folder ini.
3. Jalankan:
   npm install
4. Salin `.env.example` menjadi `.env`.
5. Isi:
   - AI_API_KEY
   - AI_BASE_URL
   - AI_MODEL
6. Jalankan:
   npm start

API:
GET  /api/health
POST /api/generate

Contoh body:
{
  "mode": "Content",
  "prompt": "Buatkan 7 Reels untuk menjual AI Prompt Vault kepada creator pemula."
}

## Catatan keamanan
API key hanya disimpan di backend `.env`. Jangan menaruh API key di `index.html`, `app.js`, atau repository publik.

## Integrasi UI
Ubah fungsi `generate()` pada frontend agar POST ke:
http://localhost:8787/api/generate

Setelah backend aktif, output demo dapat diganti dengan hasil model AI sungguhan.
